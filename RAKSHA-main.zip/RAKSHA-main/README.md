# RAKSHA
Our project is about Women Safety , which contains features  like alarm system , high frequency detection , Destination  tracking system.
